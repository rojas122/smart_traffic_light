  
#ifndef config_H
#define	config_H

#define _XTAL_FREQ 4000000L


#endif	/* XC_HEADER_TEMPLATE_H */

